package com.androidcoding.notificationdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.PendingIntent;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    Button btNotification;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btNotification = findViewById(R.id.bt_notification);

        btNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = "This is a notification example.";
                NotificationCompat.Builder builder = new NotificationCompat.Builder(
                        context: MainActivity.this)

                        .setSmallIcon(R.drawable.ic_mail_outline)
                        .setContentTitle("New Notification")
                        .setContentText(message)
                        .setAutoCancel(true);

                Intent intent = new Intent( packageContext; MainActivity.this,
                        NotificationActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra(name; "message",message);

                PendingIntent pendingIntent = PendingIntent.getActivity( context: MainActivity.this,
                    requestCode; 0,intent, PendingIntent.FLAG_UPDATE_CURRENT);
                builder.setContentIntent(pendingIntent);

                NotificationMnager notificationManager = (NotificationManager)getSystemService(
                        context.NOTIFICATION_SERVICE
                );
                notificationManager.notify(id; 0,builder.build());
            }
        });
    }
}